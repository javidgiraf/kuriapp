<?php
/**
 * @title            QR Code Example
 *
 * @author           Pierre-Henry Soria <ph7software@gmail.com>
 * @copyright        (c) 2012-2017, Pierre-Henry Soria. All Rights Reserved.
 * @license          GNU General Public License <http://www.gnu.org/licenses/gpl.html>
 */

require 'QRCode.class.php'; // Include the QRCode class
$oQRC = new QRCode; // Create vCard Object

$html = '';
 
if(isset($_POST['vcard-post'])){

  try {

    $fname = isset($_POST['firstname'])? $_POST['firstname']: '';
    $lname = isset($_POST['lastname'])? $_POST['lastname']: '';
    $phone = isset($_POST['workphone'])? $_POST['workphone']: '';
    $email = isset($_POST['email'])? $_POST['email']: '';
    $company = isset($_POST['company'])? $_POST['company']: '';
    $website = isset($_POST['website'])? $_POST['website']: '';
    $role = isset($_POST['role'])? $_POST['role']: '';
    $address = isset($_POST['address'])? $_POST['address']: '';
      /**
       * If you have PHP 5.4 or higher, you can instantiate the object like this:
       * (new QRCode)->fullName('...')->... // Create vCard Object
       */
      
      $oQRC->name($fname)// Add Full Name
          ->fullName($lname)
          ->organization($company)// Add Nickname
          ->workPhone($phone)
          ->email($email)// Add Email Address
          ->url($website)// Add URL Website
          ->role($role)// Add Note
          ->address($address)
          ->finish(); // End vCard

     //   echo '<a href="' . $oQRC->get(500) . '" download><img src="' . $oQRC->get(500) . '" alt="QR Code" /></a>'; // Generate and display the QR Code
        //$oQRC->display(500); // Display

        $html .='
          <h4 class="d-flex justify-content-between align-items-center mb-3"><span class="text-primary">QR CODE</span></h4>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-center lh-sm" id="qrcode-img"><img src="'.$oQRC->get(500).'" alt="" id="qr-img" /></li>
          </ul>
        <div class="input-group d-flex justify-content-center">           
            <button type="button" class="btn btn-warning" onClick="downloadImage()">Download</button>
        </div>';

        echo $html;
    

  } catch (Exception $oExcept) {
      echo '<p><b>Exception launched!</b><br /><br />' .
          'Message: ' . $oExcept->getMessage() . '<br />' .
          'File: ' . $oExcept->getFile() . '<br />' .
          'Line: ' . $oExcept->getLine() . '<br />' .
          'Trace: <p/><pre>' . $oExcept->getTraceAsString() . '</pre>';
  }

}else if(isset($_POST['url-post'])){

  try {

    $weburl = isset($_POST['weburl'])? $_POST['weburl']: '';
    /**
     * If you have PHP 5.4 or higher, you can instantiate the object like this:
     * (new QRCode)->fullName('...')->... // Create url Object
     */
        
     // Create URL Code
    $oQRC->Weburl($weburl);  
    /* display QR code image */
     

    //   echo '<a href="' . $oQRC->get(500) . '" download><img src="' . $oQRC->get(500) . '" alt="QR Code" /></a>'; // Generate and display the QR Code
    //$oQRC->display(500); // Display

    $html .='
      <h4 class="d-flex justify-content-between align-items-center mb-3"><span class="text-primary">QR CODE</span></h4>
      <ul class="list-group mb-3">
        <li style="list-style: none;">'.$weburl.'</li>
        <li class="list-group-item d-flex justify-content-center lh-sm" id="qrcode-img" style="list-style: none;">
        <img src="'. $oQRC->getQrcode(500).'" alt="" id="qr-img" /></li>
      </ul>
    <div class="input-group d-flex justify-content-center">           
        <button type="button" class="btn btn-warning" onClick="downloadImage()">Download</button>
    </div>';

    echo $html;
    

  } catch (Exception $oExcept) {
      echo '<p><b>Exception launched!</b><br /><br />' .
          'Message: ' . $oExcept->getMessage() . '<br />' .
          'File: ' . $oExcept->getFile() . '<br />' .
          'Line: ' . $oExcept->getLine() . '<br />' .
          'Trace: <p/><pre>' . $oExcept->getTraceAsString() . '</pre>';
  }

   
}else{

  $oQRC->Weburl('yesmachinery.ae');  
    /* display QR code image */
     

    //   echo '<a href="' . $oQRC->get(500) . '" download><img src="' . $oQRC->get(500) . '" alt="QR Code" /></a>'; // Generate and display the QR Code
    //$oQRC->display(500); // Display

  $html .='
      <h4 class="d-flex justify-content-between align-items-center mb-3"><span class="text-primary">QR CODE</span></h4>
      <ul class="list-group mb-3">
        <li class="list-group-item d-flex justify-content-center lh-sm" id="qrcode-img"><img src="'. $oQRC->getQrcode(500).'" alt="" id="qr-img" /></li>
      </ul>
    <div class="input-group d-flex justify-content-center">           
        <button type="button" class="btn btn-warning" onClick="downloadImage()">Download</button>
    </div>';

  echo $html;

}

?>